<?php
@include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $brand = mysqli_real_escape_string($conn, $_POST['brand']);
    $model = mysqli_real_escape_string($conn, $_POST['model']);

    $insert = "INSERT INTO order_form(name, email, address, brand, model) VALUES ('$name', '$email', '$address', '$brand', '$model')";
    mysqli_query($conn, $insert);

    mysqli_close($conn);
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="formStyles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Project D</title>
</head>
<body>
            <!-- nav bar -->
    <section id="header">
        <a href="#"><img src="images/Shoplogo3.png" alt="LOGO"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a class="active" href="form.php">ORDER</a></li>
                <li>
                    <a href="#">BRANDS ▼</a>
                    <ul class="dropdown">
                        <li class="dpdcontent"><a href="#">ADVAN</a></li>
                        <li><a href="#">BBS</a></li>
                        <li><a href="#">ENKEI</a></li>
                        <li><a href="#">FIFTEEN52</a></li>
                        <li><a href="#">ROTA</a></li>
                        <li><a href="#">ROTIFORM</a></li>
                        <li><a href="#">VOLK RACING</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </section>
    
    <!-- Forms -->
    <section id="order_form">
    <h2>Acknowledgement Receipt</h2>
        <div class = "invoice-area">        
            <div class = "receipt">
                Thank you for your purchase <?php echo $name?>.<br>
                Your set of <?php echo $brand . " " . $model ?> will be prepared as soon as possible.<br>
                We will contact you using your provided email regarding <br>
                this transaction and may take 3 to 5 business days to process.<br>
                Thank you for your continued patronage.<br>
            </div>
            <div class = "shopLogo">
                <img src = "images/Shoplogo3.png" alt = "logo">
            </div>
        </div>

    </section>
     <!-- Code for Footer -->
    <footer class="section-p1">

        <div class="col">
            <img src="images/Shoplogo3.png" alt="Project D Logo">
            <h4>Contact</h4>
            <p> <strong>Address:</strong>Project D 318 Co. Bonny Serrano Avenue, San Juan, Metro Manila</p>
            <p><strong>Phone:</strong> +63 923 654 7805 </p>
            <p><strong>Hours:</strong> 9:00 AM - 9:00 PM | Mon-Sat</p>
        </div>

        <div class="col install">
            <h4>Secured Payment Gateways</h4>
            <img src="images/paymentmethod_1_350x50.png" alt="Payment Gateways">
        </div>

        <div class="copyright">
            <p>© 2023 | GROUP 7 Project D</p>
        </div>
    </footer>
    <!-- End of Code for Footer -->
</body>
</html>