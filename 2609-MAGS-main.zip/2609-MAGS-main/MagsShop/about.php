<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Project D</title>
</head>

<body>
    <!-- Code for Navigation Bar -->
    <section id="header">
        <a href="#"><img src="images/Shoplogo3.png" alt="LOGO"></a>
        <div>
            <ul id="navbar">
                <li><a href="index.php">HOME</a></li>
                <li><a class="active" href="about.php">ABOUT</a></li>
                <li><a href="form.php">ORDER</a></li>
                <li>
                    <a href="#">BRANDS ▼</a>
                    <ul class="dropdown">
                        <li class="dpdcontent"><a href="/MagsShop/advan.php">ADVAN</a></li>
                        <li><a href="/MagsShop/bbs.php">BBS</a></li>
                        <li><a href="/MagsShop/enkei.php">ENKEI</a></li>
                        <li><a href="/MagsShop/fifteen52.php">FIFTEEN52</a></li>
                        <li><a href="/MagsShop/ozracing.php">OZ RACING</a></li>
                        <li><a href="/MagsShop/rota.php">ROTA</a></li>
                        <li><a href="/MagsShop/rotiform.php">ROTIFORM</a></li>
                        <li><a href="/MagsShop/volk.php">VOLK RACING</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </section>
    <section id="hero2">
        <div class="hero-image"></div>
    </section>
    <!--   -->
    <section id="brand2" class="about">
        <h2> About Us </h2>
        <div class="pro-container">
            <div class="pro2">
                <h5>Welcome to Project D, your ultimate destination for high-quality car wheels! At Project D, we take pride in offering an extensive range of top-notch wheels to enhance the performance, style, and safety of your vehicle.
                </h5>
                <br>
                <h5>
                    As a leading car wheel seller, we understand that the right set of wheels can make a significant difference in both the aesthetics and functionality of your car. That's why we strive to provide our customers with a diverse selection of wheels that caters to various tastes, preferences, and vehicle types.
                </h5>
                <br>
                <h5>
                    Our commitment to quality is unwavering. We work closely with reputable manufacturers known for their exceptional craftsmanship, cutting-edge technology, and use of premium materials. This ensures that every wheel we offer is durable, reliable, and built to withstand the demands of the road.
                </h5>
                <br>
                <h5>
                    At Project D, we believe that customization is key to making your vehicle truly unique. That's why we offer a wide range of styles, finishes, and sizes to suit your individual preferences and vehicle specifications. Whether you're looking for sleek and sporty alloy wheels or rugged and durable steel wheels, we have the perfect match for you.
                </h5>

                <br>

                <h5>
                    We understand that purchasing wheels can be overwhelming, which is why our team of knowledgeable professionals is always ready to assist you. Our friendly staff is well-versed in the latest industry trends and can provide expert advice on choosing the right wheels for your vehicle. We prioritize customer satisfaction and strive to ensure that your experience with us is nothing short of exceptional.
                </h5>
                <br>
                <h5>
                    At Project D, we believe that value goes beyond just the product. That's why we offer competitive prices without compromising on quality. We aim to make your wheel-buying experience affordable and hassle-free, allowing you to enjoy the benefits of superior wheels without breaking the bank.
                </h5>
                <br>
                <h5>
                    We are dedicated to building long-term relationships with our customers and are committed to providing outstanding service at every step. From the moment you browse our extensive inventory to the moment your new wheels are installed, we are here to make your journey with us a smooth and enjoyable one.
                </h5>
                <br>
                <h5>
                    Choose Project D as your trusted car wheel seller and let us help you transform your vehicle into a statement of style and performance. Discover the perfect wheels to match your vision and hit the road with confidence.
                </h5>

            </div>
            <!-- might add a shop now button to redirect back to brand logos -->
        </div>
    </section>

    <!-- Code for Footer -->
    <footer class="section-p1">

        <div class="col">
            <img src="/MagsShop/images/Shoplogo3.png" alt="Project D Logo">
            <h4>Contact</h4>
            <p> <strong>Address:</strong>Project D 318 Co. Bonny Serrano Avenue, San Juan, Metro Manila</p>
            <p><strong>Phone:</strong> +63 923 654 7805 </p>
            <p><strong>Hours:</strong> 9:00 AM - 9:00 PM | Mon-Sat</p>
        </div>

        <div class="col install">
            <h4>Secured Payment Gateways</h4>
            <img src="/MagsShop/images/paymentmethod_1_350x50.png" alt="Payment Gateways">
        </div>

        <div class="copyright">
            <p>© 2023 | GROUP 7 Project D</p>
        </div>
    </footer>
    <!-- End of Code for Footer -->
    <script src="script.js"></script>
</body>

</html>