<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VOLK RACING | Project D</title>
    <link rel="stylesheet" href="brStyles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.15.4/css/all.css" />
</head>

<body>

    <!-- Code for Navigation Bar -->
    <section id="header">
        <a href="#"><img src="images/Shoplogo3.png" alt="LOGO"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="form.php">ORDER</a></li>
                <li>
                    <a href="#">BRANDS ▼</a>
                    <ul class="dropdown">
                        <li class="dpdcontent"><a href="advan.php">ADVAN</a></li>
                        <li><a href="bbs.php">BBS</a></li>
                        <li><a href="enkei.php">ENKEI</a></li>
                        <li><a href="fifteen52.php">FIFTEEN52</a></li>
                        <li><a href="ozracing.php">OZ RACING</a></li>
                        <li><a href="rota.php">ROTA</a></li>
                        <li><a href="rotiform.php">ROTIFORM</a></li>
                        <li><a href="volk.php">VOLK RACING</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </section>
    <!-- End of Code for Navigation Bar -->

    <!-- Code for Hero Image/Banner Image -->
    <section id="hero">
        <h4>"Life's simple..</h4>
        <h2>Make choices and</h2>
        <h1>don't look back."</h1>
        <p>- Han Seoul-Oh</p>
    </section>
    <!-- End of Code for Hero Image/Banner Image -->

    <section id="prodetails" class="section-p1">
        <div class="single-pro-image">
            <img src="images/volk/VOLK ZE40 Black.JPG" width="100%" id="MainImg" alt="">

            <div class="small-img-group">
                <div class="small-img-col">
                    <img src="images/volk/VOLK ZE40 Black.JPG" width="100%" class="small-img" alt="">
                </div>
                <div class="small-img-col">
                    <img src="images/volk/VOLK ZE40 Bronze.JPG " width=" 100%" class="small-img" alt="">
                </div>
                <div class="small-img-col">
                    <img src="images/volk/VOLK ZE40 Dash White-REDOT.JPG" width="100%" class="small-img" alt="">
                </div>
                <div class="small-img-col">
                    <img src="images/volk/VOLK ZE40 Mag Blue.JPG" width="100%" class="small-img" alt="">
                </div>
            </div>
        </div>

        <div class="single-pro-details">
            <h2>VOLK RACING</h2>
            <h2>ZE40</h2>
            <h4>₱ 41,000 - ₱ 48,000</h4>
            <a href="form.php"><button class="normal">Order</button></a>
            <h4>Product Details</h4>
            <span>The ZE40 has an aesthetic finish, with machined logos and high-speed air valves. The barrel has anti-slip bead knurling, a design used in Formula 1 competition wheels, to ensure excellent grip between the tyre and wheel. Depending on the width and offset chosen, the spokes feature in 4 different concave faces.</span>
        </div>
    </section>

    <!-- Code for Footer -->
    <footer class="section-p1">

        <div class="col">
            <img src="images/Shoplogo3.png" alt="Project D Logo">
            <h4>Contact</h4>
            <p> <strong>Address:</strong>Project D 318 Co. Bonny Serrano Avenue, San Juan, Metro Manila</p>
            <p><strong>Phone:</strong> +63 923 654 7805 </p>
            <p><strong>Hours:</strong> 9:00 AM - 9:00 PM | Mon-Sat</p>
        </div>

        <div class="col install">
            <h4>Secured Payment Gateways</h4>
            <img src="images/paymentmethod_1_350x50.png" alt="Payment Gateways">
        </div>

        <div class="copyright">
            <p>© 2023 | GROUP 7 Project D</p>
        </div>
    </footer>
    <!-- End of Code for Footer -->

    <script>
        var MainImg = document.getElementById("MainImg")
        var smallimg = document.getElementsByClassName("small-img");

        smallimg[0].onclick = function() {
            MainImg.src = smallimg[0].src;
        }
        smallimg[1].onclick = function() {
            MainImg.src = smallimg[1].src;
        }
        smallimg[2].onclick = function() {
            MainImg.src = smallimg[2].src;
        }
        smallimg[3].onclick = function() {
            MainImg.src = smallimg[3].src;
        }
    </script>


    <script src="script.js"></script>
</body>

</html>