<?php
@include 'config.php';

// if (isset($_POST['submit'])) {
//     $name = mysqli_real_escape_string($conn, $_POST['name']);
//     $email = mysqli_real_escape_string($conn, $_POST['email']);
//     $address = mysqli_real_escape_string($conn, $_POST['address']);
//     $brand = mysqli_real_escape_string($conn, $_POST['brand']);
//     $model = mysqli_real_escape_string($conn, $_POST['model']);

//     $insert = "INSERT INTO order_form(name, email, address, brand, model) VALUES ('$name', '$email', '$address', '$brand', '$model')";
//     mysqli_query($conn, $insert);

//     mysqli_close($conn);
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="formStyles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Project D</title>
</head>

<body>
    <!-- nav bar -->
    <section id="header">
        <a href="index.php"><img src="images/Shoplogo3.png" alt="LOGO"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a class="active" href="form.php">ORDER</a></li>
                <li>
                    <a href="#">BRANDS ▼</a>
                    <ul class="dropdown">
                        <li class="dpdcontent"><a href="advan.php">ADVAN</a></li>
                        <li><a href="bbs.php">BBS</a></li>
                        <li><a href="enkei.php">ENKEI</a></li>
                        <li><a href="fifteen52.php">FIFTEEN52</a></li>
                        <li><a href="rota.php">ROTA</a></li>
                        <li><a href="rotiform.php">ROTIFORM</a></li>
                        <li><a href="volk.php">VOLK RACING</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </section>
    <!-- Forms -->
    <section id="order_form">
        <h2>Order Form</h2><br>
        <div class="form-area">
            <form name="form1" id="form1" action="action_page.php" method="post">
                <div class="form">
                    <label for="name">Name:</label>
                    <input required type="text" id="name" name="name">
                </div>

                <div class="form">
                    <label for="email">Email:</label>
                    <input required type="email" id="email" name="email">
                </div>

                <div class="form">
                    <label for="address">Address:</label>
                    <textarea required id="address" name="address"></textarea>
                </div>

                <div class="drop-down">
                    <div class="form" class="active">
                        <label for="brand">Brand:</label>
                        <select required id="brand" name="brand">
                            <option value="">Please select a brand</option>
                            <option value="Advan">Advan</option>
                            <option value="BBS">BBS</option>
                            <option value="Enkei">Enkei</option>
                            <option value="Fifteen52">Fifteen52</option>
                            <option value="OZ Racing">OZ Racing</option>
                            <option value="Rota">Rota</option>
                            <option value="Rotiform">Rotiform</option>
                            <option value="Volk Rays">Volk Rays</option>
                        </select>
                                        
                        <label for="model">Model:</label>
                        <select required id="model" name="model" disabled>
                            <option value="">Please select a brand first</option>
                        </select>
                    
                        <div class="button">
                            <input type="submit" value="Submit">
                        </div>


                    </div>
                </div>
            </form>
        </div>
    </section>

    

    <!-- Code for Footer -->
    <footer class="section-p1">

        <div class="col">
            <img src="images/Shoplogo3.png" alt="Project D Logo">
            <h4>Contact</h4>
            <p> <strong>Address:</strong>Project D 318 Co. Bonny Serrano Avenue, San Juan, Metro Manila</p>
            <p><strong>Phone:</strong> +63 923 654 7805 </p>
            <p><strong>Hours:</strong> 9:00 AM - 9:00 PM | Mon-Sat</p>
        </div>

        <div class="col install">
            <h4>Secured Payment Gateways</h4>
            <img src="images/paymentmethod_1_350x50.png" alt="Payment Gateways">
        </div>

        <div class="copyright">
            <p>© 2023 | GROUP 7 Project D</p>
        </div>
    </footer>
    <!-- End of Code for Footer -->

    <script>
        var brandDropdown = document.getElementById("brand");
        var modelDropdown = document.getElementById("model");

        var advanModels = ["GT Premium Black", "GT Premium Gold", "GT Premium Navy","GT Premium Silver", "Oni 2 Black Metallic", "Oni 2 Candy Red", "Oni 2 Champagne Gold", "Oni 2 Diamond Cut", "RG-4 Hyper Black", "RG-4 Racing Copper", "RG-4 Raching White", "RG-4 Semi Gloss Black"];
        var bbsModels = ["FI-R Bronze", "FI-R Platinum Silver", "FI-R Satin Black", "FI-R Diamond Black", "LM Diamond Silver", "LM Diamond Black", "LM Gold and Black Diamond", "LM-R Diamond Silver", "LM-R Diamond Black & Silver", "LM-R Diamond Black Black", "LM-R Diamond Silver & Black"];
        var enkeiModels = ["RPF1 Black", "RPF1 Gold", "RPF1 Matte Silver", "RPF1 Silver", "ENKEI92 Gold", "ENKEI92 Silver", "ENKEI92 Black", "T6R Gloss Black", "T6R Gloss Gunmetal", "T6R Matte Bronze", "TY-5 Gloss Black", "TY-5 Hyper Silver"];
        var fifteen52Models = ["Apex Frosted Graphite", "Apex Rally White", "Podium Frosted Graphite", "Podium Rally White", "Podium Speed Silver", "Tarmac Asphalt Black", "Tarmac Gold", "Tarmac Rally White", "Turbomac Asphalt Black","Turbomac Gold", "Turbomac Rally White", "Turbomac Speed Silver"];
        var ozModels = ["Alleggerita HLT Black", "Alleggerita HLT Red", "Alleggerita HLT White", "Alleggerita HLT Silver", "Ultraleggera HLT CL Black",  "Ultraleggera HLT CL Red", "Ultraleggera HLT CL Gold",  "Ultraleggera HLT CL White", "Ultraleggera Black",  "Ultraleggera Bronze", "Ultraleggera Gold",  "Ultraleggera White"];
        var rotaModels = ["Fighter Bronze", "Fighter Gunmetal", "Fighter Hyper Black", "Fighter White", "RB Black", "RB Gold", "RB Silver", "RB White", "Slipstream Gunmetal", "Slipstream Matte Black", "Slipstream Silver", "Slipstream White"];
        var rotiformModels = ["BLQ-C Satin Black", "BLQ-C SSilver", "BLQ-C White", "DTM Silver", "DTM Irish Green", "FLG Satin Black", "FLG Silver", "LAS-R Black", "LAS-R Silver", "RSE Anthracite", "RSE Silver"];
        var volkModels = ["57DX-R Dark Gunmental", "57DX-R Gold", "57DX-R Bronze", "57DX-R Matte Graphite", "TE37 Navy", "TE37 Bronze", "TE37 Dark Gunmetal", "TE37 Gravel White", "ZE40 Black", "ZE40 Bronze", "ZE40 White-REDOT", "ZE40 Mag Blue", ];


        brandDropdown.addEventListener("change", function() {
            modelDropdown.innerHTML = "";
            modelDropdown.disabled = false;

            var models = [];

            switch (brandDropdown.value) {
                case "Advan":
                    models = advanModels;
                    break;
                case "BBS":
                    models = bbsModels;
                    break;
                case "Enkei":
                    models = enkeiModels;
                    break;
                case "Fifteen52":
                    models = fifteen52Models;
                    break;
                case "OZ Racing":
                    models = ozModels;
                    break;
                case "Rota":
                    models = rotaModels;
                    break;
                case "Rotiform":
                    models = rotiformModels;
                    break;
                case "Volk Rays":
                    models = volkModels;
                    break;
                default:
                    modelDropdown.disabled = true;
                    modelDropdown.innerHTML = "<option value=''>Please select a brand first</option>";
            }

            if (models.length) {
                for (var i = 0; i < models.length; i++) {
                    var option = document.createElement("option");
                    option.value = models[i];
                    option.text = models[i];
                    modelDropdown.appendChild(option);
                }
            } else {
                modelDropdown.disabled = true;
                modelDropdown.innerHTML = "<option value=''>No models available</option>";
            }
        });
    </script>

</body>

</html>
