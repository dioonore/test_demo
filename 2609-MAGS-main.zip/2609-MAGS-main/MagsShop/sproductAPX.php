<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIFTEEN52 | Project D</title>
    <link rel="stylesheet" href="/MagsShop/brStyles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.15.4/css/all.css" />
</head>

<body>

    <!-- Code for Navigation Bar -->
    <section id="header">
        <a href="#"><img src="/MagsShop/images/Shoplogo3.png" alt="LOGO"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="form.php">ORDER</a></li>
                <li>
                    <a href="#">BRANDS ▼</a>
                    <ul class="dropdown">
                        <li class="dpdcontent"><a href="/MagsShop/advan.php">ADVAN</a></li>
                        <li><a href="/MagsShop/bbs.php">BBS</a></li>
                        <li><a href="/MagsShop/enkei.php">ENKEI</a></li>
                        <li><a href="/MagsShop/fifteen52.php">FIFTEEN52</a></li>
                        <li><a href="/MagsShop/ozracing.php">OZ RACING</a></li>
                        <li><a href="/MagsShop/rota.php">ROTA</a></li>
                        <li><a href="/MagsShop/rotiform.php">ROTIFORM</a></li>
                        <li><a href="/MagsShop/volk.php">VOLK RACING</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </section>
    <!-- End of Code for Navigation Bar -->

    <!-- Code for Hero Image/Banner Image -->
    <section id="hero">
        <h4>"Life's simple..</h4>
        <h2>Make choices and</h2>
        <h1>don't look back."</h1>
        <p>- Han Seoul-Oh</p>
    </section>
    <!-- End of Code for Hero Image/Banner Image -->

    <section id="prodetails" class="section-p1">
        <div class="single-pro-image">
            <img src="/MagsShop/images/fifteen52/1552 APEX Frosted Graphite.JPG" width="100%" id="MainImg" alt="">

            <div class="small-img-group">
                <div class="small-img-col">
                    <img src="/MagsShop/images/fifteen52/1552 APEX Frosted Graphite.JPG" width="100%" class="small-img" alt="">
                </div>
                <div class="small-img-col">
                    <img src="/MagsShop/images/fifteen52/1552 APEX Frsted Grph 2.JPG" width="100%" class="small-img" alt="">
                </div>
                <div class="small-img-col">
                    <img src="/MagsShop/images/fifteen52/1552 APEX Rally White.JPG" width="100%" class="small-img" alt="">
                </div>
                <div class="small-img-col">
                    <img src="/MagsShop/images/fifteen52/1552 APEX Rally White 2.JPG" width="100%" class="small-img" alt="">
                </div>
            </div>
        </div>

        <div class="single-pro-details">
            <h2>FIFTEEN52</h2>
            <h2>Apex</h2>
            <h4>Request for price quotation</h4>
            <a href="form.php"><button class="normal">Order</button></a>
            <h4>Product Details</h4>
            <span>Introducing a split 7 spoke mesh design featuring our signature Super Touring Lug Cap System. The Apex is built with the enthusiast platforms in mind, with maximum caliper clearance and an outer lip channel to reduce weight. The Apex introduces our new Tech nut, with scalloped cuts to give a modern center-lock look and comes standard in black anodized finish.</span>
        </div>
    </section>

    <!-- Code for Footer -->
    <footer class="section-p1">

        <div class="col">
            <img src="/MagsShop/images/Shoplogo3.png" alt="Project D Logo">
            <h4>Contact</h4>
            <p> <strong>Address:</strong>Project D 318 Co. Bonny Serrano Avenue, San Juan, Metro Manila</p>
            <p><strong>Phone:</strong> +63 923 654 7805 </p>
            <p><strong>Hours:</strong> 9:00 AM - 9:00 PM | Mon-Sat</p>
        </div>

        <div class="col install">
            <h4>Secured Payment Gateways</h4>
            <img src="/MagsShop/images/paymentmethod_1_350x50.png" alt="Payment Gateways">
        </div>

        <div class="copyright">
            <p>© 2023 | GROUP 7 Project D</p>
        </div>
    </footer>
    <!-- End of Code for Footer -->

    <script>
        var MainImg = document.getElementById("MainImg")
        var smallimg = document.getElementsByClassName("small-img");

        smallimg[0].onclick = function() {
            MainImg.src = smallimg[0].src;
        }
        smallimg[1].onclick = function() {
            MainImg.src = smallimg[1].src;
        }
        smallimg[2].onclick = function() {
            MainImg.src = smallimg[2].src;
        }
        smallimg[3].onclick = function() {
            MainImg.src = smallimg[3].src;
        }
    </script>


    <script src="script.js"></script>
</body>

</html>